//
//  IF1977Filter.h
//  InstaFilters
//
//  Created by Di Wu on 2/28/12.
//  Copyright (c) 2012 twitter:@diwup. All rights reserved.
//

#import "IFImageFilter.h"

@interface IF1977Filter : IFImageFilter

@end
