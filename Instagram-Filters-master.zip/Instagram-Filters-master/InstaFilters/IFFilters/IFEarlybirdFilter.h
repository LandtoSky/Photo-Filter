//
//  IFEarlybirdFilter.h
//  InstaFilters
//
//  Created by Di Wu on 2/28/12.
//  Copyright (c) 2012 twitter:@diwup. All rights reserved.
//

#import "IFImageFilter.h"

@interface IFEarlybirdFilter : IFImageFilter

@end
