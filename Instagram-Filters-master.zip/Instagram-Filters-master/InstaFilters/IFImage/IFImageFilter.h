//
//  IFImageFilter.h
//  InstaFilters
//
//  Created by Di Wu on 2/28/12.
//  Copyright (c) 2012 twitter:@diwup. All rights reserved.
//

#import "GPUImageFilter.h"

@interface IFImageFilter : GPUImageFilter {
    GLuint filterSourceTexture3, filterSourceTexture4, filterSourceTexture5, filterSourceTexture6;
}

@end
